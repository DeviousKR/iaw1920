<?php
//We start the session and we include our word dictionary.
session_start();
include "words.php";
$_SESSION['solution'] = False;

/*Preparatory variables, res is the display variable, disp will be the variable
that will manage the selected words*/
$disp = [];
$res = "";

/*We check that a difficulty has been set from the difficulty selector page if not
baseline number of words is set to 5*/
$_SESSION['dif'] = empty($_GET['dif']) ? 5 : $_GET['dif'];
if (!preg_match('/^[1-9][0-9]$|^[2-9]$|^100$/',$_SESSION['dif'])) {
  header("Location:index.php");
  exit;
}
$dif = $_SESSION['dif'];


/*we create a group of random array keys from our dictionary array, then we search
which words does those keys belong to*/

$keys = array_rand($word, $dif);
foreach ($keys as $value) {
  $disp[] = $word[$value];
}

/*we display the words into a button-like element to the user*/
foreach ($disp as $key => $value) {
  $res = $res."<button class=\"btn btn-info mt-5 mb-5 ml-3\" disabled>$value</button>";
}

/*we save this displayed words into a session array*/
$_SESSION["guess"] = $disp;

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Memory game</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
    <style>
      body {
        background-color: #000000;
        font-family:"Trebuchet MS", Helvetica, sans-serif'
      }
    </style>
  </head>
  <body>
   <div class="container">
     <div class="jumbotron mt-4 bg-secondary text-white text-center">
       <h1 class="display-3">Memory Game</h1>
       <p class="lead">You have five (5) seconds to memorize the next words!</p>
     <hr>
     <?=$res?>
     </div>
   </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <script src="bower_components/popper.js/dist/popper.min.js"></script>
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script type="text/javascript">
     $(setTimeout(function(){location="P30_form.php"},5000));
    </script>
  </body>
</html>
