<?php
function MoveLeft($numbers) {
  $count = 0;
  $checkarray = [];
  for ($i=0; $i < count($numbers); $i++) {
    if ($numbers[$i] == 0) {
      $value = 0;
      while ($value == 0) {
        $value = $numbers[$i+1];
        $count++;
      }
      $i++;
      $Onumbers[] = $value;
    } else {
      $Onumbers[] = $numbers[$i];
    }
  }
  for ($i=0; $i < $count ; $i++) {
      $Onumbers[] = 0;
  }
  return $Onumbers;
}
$array = [];
$array[] = 2;
$array[] = 0;
$array[] = 4;
$array[] = 0;
$array[] = 2;
$array[] = 0;
$array[] = 4;
$array[] = 4;

$count = MoveLeft($array);
print_r($count);








?>
